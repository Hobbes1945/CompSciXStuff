package com.tychovonr.Riemann;

public class SimpsonsRule {
}
