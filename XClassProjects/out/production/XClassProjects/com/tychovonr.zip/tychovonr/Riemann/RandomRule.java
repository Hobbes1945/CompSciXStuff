package com.tychovonr.Riemann;

public class RandomRule {
}
